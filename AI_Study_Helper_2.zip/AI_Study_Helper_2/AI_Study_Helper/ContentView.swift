//
//  ContentView.swift
//  AI_Study_Helper
//
//  Created by Leonardo Sbicca on 30/03/25.
//

import SwiftUI

struct ContentView: View {
    @State private var restartFlow = false

    var body: some View {
        NavigationView {
            PhotoInputView(restartFlow: $restartFlow)
        }
        // When restartFlow changes, the NavigationView is reloaded
        .id(restartFlow)
    }
}
