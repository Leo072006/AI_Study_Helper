//
//  OCRProcessorView.swift
//  AI_Study_Helper
//
//  Created by Leonardo Sbicca on 31/03/25.
//
// OCRProcessorView.swift

import SwiftUI
import Vision
import VisionKit

struct OCRProcessorView: View {
    let inputImage: UIImage
    @Binding var restartFlow: Bool

    @State private var extractedText: String = ""
    @State private var aiAnswer: String = ""
    @State private var isLoading = true
    @State private var isAskingAI = false
    @State private var errorMessage: String?
    
    // 🔥 Usage Tracking 🔥
    @AppStorage("questionsAskedToday") private var questionsAskedToday = 0
    @AppStorage("lastResetDate") private var lastResetDate = ""
    
    var body: some View {
        VStack(spacing: 20) {
            if isLoading {
                ProgressView("Reading your question...")
                    .padding()
            } else if let error = errorMessage {
                Text("❌ Error: \(error)")
                    .foregroundColor(.red)
            } else if isAskingAI {
                ProgressView("Asking AI to solve...")
                    .padding()
            } else if !aiAnswer.isEmpty {
                ScrollView {
                    Text(aiAnswer)
                        .font(.system(.body, design: .monospaced))
                        .padding()
                }

                // Copy & Retry buttons
                HStack(spacing: 20) {
                    Button("📋 Copy") {
                        UIPasteboard.general.string = aiAnswer
                    }
                    .padding()
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(10)
                    
                    Button("🔁 Retry") {
                        askGPTWithLimit()
                    }
                    .padding()
                    .background(Color.orange.opacity(0.2))
                    .cornerRadius(10)
                }

                // Ask Another Question button
                Button("🔙 Ask Another Question") {
                    restartFlow.toggle()
                }
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(10)

            } else {
                ScrollView {
                    Text(extractedText)
                        .font(.body)
                        .padding()
                }

                Button("Ask AI to Solve It") {
                    askGPTWithLimit()
                }
                .padding()
                .background(Color.blue.opacity(0.2))
                .cornerRadius(10)
            }
        }
        .padding()
        .onAppear {
            performOCR(on: inputImage)
            resetQuestionsIfNewDay()
        }
        .navigationTitle("Your Question")
    }

    func askGPTWithLimit() {
        resetQuestionsIfNewDay()

        if questionsAskedToday >= 3 {
            aiAnswer = "🚫 You've reached your limit of 3 questions today. Please come back tomorrow!"
            return
        }

        isAskingAI = true
        GPTService.askGPT(question: extractedText) { response in
            self.aiAnswer = response
            self.isAskingAI = false

            // Increment the counter each successful request
            self.questionsAskedToday += 1
        }
    }

    func resetQuestionsIfNewDay() {
        let today = DateFormatter.localizedString(from: Date(), dateStyle: .short, timeStyle: .none)

        if lastResetDate != today {
            questionsAskedToday = 0
            lastResetDate = today
        }
    }

    // OCR logic (unchanged)
    func performOCR(on image: UIImage) {
        guard let cgImage = image.cgImage else {
            self.errorMessage = "Invalid image format"
            self.isLoading = false
            return
        }

        let request = VNRecognizeTextRequest { request, error in
            if let error = error {
                self.errorMessage = error.localizedDescription
                self.isLoading = false
                return
            }

            guard let observations = request.results as? [VNRecognizedTextObservation] else {
                self.errorMessage = "No text found"
                self.isLoading = false
                return
            }

            let recognizedStrings = observations.compactMap {
                $0.topCandidates(1).first?.string
            }

            DispatchQueue.main.async {
                self.extractedText = recognizedStrings.joined(separator: "\n")
                self.isLoading = false
            }
        }

        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true

        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                try handler.perform([request])
            } catch {
                DispatchQueue.main.async {
                    self.errorMessage = error.localizedDescription
                    self.isLoading = false
                }
            }
        }
    }
}
