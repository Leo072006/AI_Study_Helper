//
//  AI_Study_HelperApp.swift
//  AI_Study_Helper
//
//  Created by Leonardo Sbicca on 30/03/25.
//

import SwiftUI

@main
struct AI_Study_HelperApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
