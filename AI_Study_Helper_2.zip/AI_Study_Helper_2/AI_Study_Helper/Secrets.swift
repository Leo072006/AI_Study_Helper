//
//  Secrets.swift
//  AI_Study_Helper
//
//  Created by Leonardo Sbicca on 30/03/25.
//

import Foundation

struct Secrets {
    static let openAIKey = ""
}
