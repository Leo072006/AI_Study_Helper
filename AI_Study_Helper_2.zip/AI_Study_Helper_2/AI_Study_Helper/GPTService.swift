//
//  GPTService.swift
//  AI_Study_Helper
//
//  Created by Leonardo Sbicca on 31/03/25.
//
import Foundation

struct GPTService {
    
    static func askGPT(question: String, completion: @escaping (String) -> Void) {
        // 1. Prepare the API URL
        let url = URL(string: "https://api.openai.com/v1/chat/completions")!
        
        // 2. Set up the request
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(Secrets.openAIKey)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // 3. Build the JSON body
        let body: [String: Any] = [
            "model": "gpt-3.5-turbo",
            "messages": [
                ["role": "system", "content": "You are a helpful AI tutor. Explain clearly, step-by-step."],
                ["role": "user", "content": question]
            ],
            "temperature": 0.4
        ]
        
        guard let jsonData = try? JSONSerialization.data(withJSONObject: body) else {
            print("❌ Failed to convert body to JSON")
            return
        }
        
        request.httpBody = jsonData
        
        // 4. Send the request
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ Request error: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    completion("Something went wrong. Please check your internet connection.")
                }
                return
            }
            
            guard let data = data else {
                print("❌ No data in GPT response")
                DispatchQueue.main.async {
                    completion("No response from AI. Try again.")
                }
                return
            }
            
            // 🧪 DEBUG: Print raw GPT response
            do {
                let json = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                print("🧾 Full GPT Response: \(json ?? [:])")
                
                if let choices = json?["choices"] as? [[String: Any]],
                   let message = choices.first?["message"] as? [String: Any],
                   let content = message["content"] as? String {
                    
                    DispatchQueue.main.async {
                        completion(content)
                    }
                } else {
                    print("❌ GPT response format unexpected.")
                    DispatchQueue.main.async {
                        completion("Sorry, I couldn’t understand the question. Try again.")
                    }
                }
            } catch {
                print("❌ Failed to parse GPT response: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    completion("AI response error. Please try again.")
                }
            }
        }.resume()
    }
}
