//
//  PhotoInputView.swift
//  AI_Study_Helper
//
//  Created by Leonardo Sbicca on 31/03/25.
//
// PhotoInputView.swift

import SwiftUI

struct PhotoInputView: View {
    @Binding var restartFlow: Bool  // <-- Must accept a Binding<Bool>

    @State private var selectedImage: UIImage?
    @State private var showImagePicker = false
    @State private var useCamera = false

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // If user already picked an image, show preview + button
                if let image = selectedImage {
                    Image(uiImage: image)
                        .resizable()
                        .scaledToFit()
                        .frame(maxHeight: 300)
                        .cornerRadius(12)
                        .shadow(radius: 4)

                    // Navigate to OCR screen, passing the chosen image + binding
                    NavigationLink(destination: OCRProcessorView(inputImage: image, restartFlow: $restartFlow)) {
                        Text("Use This Image")
                            .padding()
                            .background(Color.blue.opacity(0.2))
                            .cornerRadius(10)
                    }
                } else {
                    Spacer()

                    // Button: Take photo
                    Button("Take a Photo") {
                        useCamera = true
                        showImagePicker = true
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(10)

                    // Button: Upload from library
                    Button("Upload from Library") {
                        useCamera = false
                        showImagePicker = true
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.orange.opacity(0.2))
                    .cornerRadius(10)

                    Spacer()
                }
            }
            .padding()
            .navigationTitle("Snap Your Homework")
            .sheet(isPresented: $showImagePicker) {
                ImagePickerView(
                    selectedImage: $selectedImage,
                    sourceType: useCamera ? .camera : .photoLibrary
                )
            }
        }
    }
}
